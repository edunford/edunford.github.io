###################################################
### An Introduction to Statistical Programming in R
### DAY 2 (April 4, 2016) 
### Eric Dunford (edunford@umd.edu)
###################################################
#########      DATA MANAGEMENT       ##############
###################################################
########### Merging and Manipulating ############## 



# Merging -----------------------------------------------

      # Consider Merging together these two small datasets
        data1 <- data.frame(ID=c("e11","e32","e4","e55","e6","e54"),
                            item1=c(NA,1,0,1,NA,1))
        
        data2 <- data.frame(ID=c("e6","e54","e66","e11","e9","e85"),
                            item2=c(1,2,2,3,1,3))
        
        
        data1
        
        data2
        
        # What is similar? What differs?
        
        
        # To merge, we need a unique ID (i.e. a column that both data frames
        # share)
        
        
        # Return only values that MATCH
        merge(x = data1,y = data2,by="ID") 
        
        
        # Return all values putting NAs where they do not match
        merge(data1,data2,by="ID",all=T) 
        
        
        # Return all values from dataset X that do not match
        merge(data1,data2,by="ID",all.x=T) 

        
        # Return all values from dataset Y that do not match
        merge(data1,data2,by="ID",all.y=T) 
        
        
        
    # What if the dataset share the same CONTENT but have different
    # column names ?
        
        colnames(data1)[1]
        colnames(data1)[1] = "respondent_ID"
        
        
        merge(data1,data2,by="ID") # error
        
        
        merge(data1,data2,by.x = "respondent_ID", by.y= "ID") # error
        
        
        
        
    # What if we want to merge by two or more columns?
        
        # Consider the following data:
        
            country1 <- data.frame(country=c("UK","Germany","Russia","Russia"),
                                  region=c("A","A","B","B"),
                                  year=c(2000,2000,2000,2001),
                                  var1 = c(1,0,1,1))
            
            country2 <- data.frame(country=c("UK","UK","Germany","Russia"),
                                  region=c("A","A","A","B"),
                                  year=c(2000,2001,2000,2001),
                                  var2 = c(2.3,4.4,5.1,3.4))
            
            
            country1
            
            country2
            
            
            
            # We can specify more than one column by feeding in a vector of
            # relevant column names
            
            merge(country1,country2,by=c("country","year","region"))
            
            
            merge(country1,country2,by=c("country","year"))
            
            
            # What's with the new column names?
            
            merge(country1,country2,by=c("country","year"),suffixes = c("A","B"))
            
            
            
            
# EXAMPLE: Merging Violent and Non-Violent Movement Data with GDP per capita --------------
            
            setwd("") # Set working directory
            
            load("protest.Rdata") # load example data
            
            
            
            # World Bank GDP per capita data from 1960 to 2015
            head(wb_gdp) 
            
            
            # The Nonviolent and Violent Campaigns and Outcomes (NAVCO) Data
            # Project is a multi-level data collection effort that catalogues
            # major nonviolent and violent resistance campaigns around the globe
            # from 1900-2011. (http://www.du.edu/korbel/sie/research/chenow_navco_data.html)
            head(navco) 
            
            
            
            # Let's merge GDPpc onto the NAVCO data.
            
            
            
            
            
            # Are the dimensions correct? Were observations dropped or added?
            
            
            
            
            # Make sure all NAVCO observations (i.e. the data set we care about) are retained.
            
            
            
            
            
# DPLYR ----------------------------------------------------   
            
            
            require(dplyr)
            
            
        # SELECT()
            
            select(navco,location,year)
            
            
            select(navco,location:camp_orgs)
            
            
            x <- select(navco,campaign:year)
            head(x)
            
            
        # SLICE() -- extract specific rows
            
            slice(navco,1:5)
            
            slice(navco,200:210)
            
            
        # ARRANGE() -- order by a specific column
            
            x <- arrange(x,year)
            View(x)
            
            
            x <- arrange(x,year,location)
            View(x)
            
            x <- arrange(x,location,year)
            View(x)
            
            
            x <- arrange(x,location,desc(year)) 
            View(x)
            
            # Here we are arranging accending by location and decending by year
            
            
        # RENAME()
            
            x <- rename(x,country=location)
            head(x)
            
            
        # FILTER()
            
            x2 <- filter(x,year >= 1990)
            head(x2)
            
            dim(x2)
            
            x2 <- filter(x,country=="Afghanistan")
            head(x2)
            
            
            x2 <- filter(x,country=="Afghanistan" & year >= 1990)
            x2
            
            
        # SUMMARIZE() 
            
            summarize(navco,ave_orgs = mean(camp_orgs,na.rm = T))
            
            summarize(navco,no_viol=sum(navco1designation))
            
            
        # GROUP_BY() + SUMMARIZE()
            
            cgroup <- group_by(navco,location)
            
            nav_sum <- summarize(cgroup,ave_orgs = mean(camp_orgs,na.rm = T))
            
            View(nav_sum)
            
            
        # TALLY()
            
            tally(cgroup)
            
            
        # MUTATE() -- create new variables
            
            mutate(navco,after_CW = year>=1990)
            
            mutate(navco,
                   after_CW = year>=1990,
                   after_CW_dummy = as.numeric(after_CW))
            
            
        # TRANSMUTE() 
            
            x <- transmute(navco,after_CW = as.numeric(year>=1990))
            head(x)
            
            
            
        # SAMPLE_N() -- randomly sample N number of obs
            
            sample_n(navco,5)
        
            
        # SAMPLE_FRAC() -- randomly sample a specific fraction of the data
            
            sample_frac(navco,.01)
        
            
        # All in all, dplyr provides some pretty useful functions for data
        # manipulation that is both consistent and clear. 
            
            
        
        # The PIPE
        
            vec <- rnorm(100,0,3)
            
            vec
            
            vec %>% sum(.) 
        
            vec %>% sum(.) %>% round(.,2)
            
            
            # Which is equivalent to 
            round(sum(vec),2)
            
            # or
            
            ob1 <- sum(vec)
            ob2 <- round(ob1,2)
            ob2
            
            # The benefit of the pipe is that it is clear. 
        
                

# EXAMPLE -----------------------------------

            # For what percent of the time did each movement in the data use
            # violence as its primary tactic? 
            
            # prim_method: 1 = "primarily non-violent tactics used", 
            #              0 = "violence tactics
            
            
            # Let's do this step by step
            
            navco %>% select(campaign,location,year,prim_method)
            
            
            
            navco %>% select(campaign,location,year,prim_method) %>% 
              mutate(violent = prim_method==0)
            
          
            
            navco %>% select(campaign,location,year,prim_method) %>% 
              mutate(violent = as.numeric(prim_method==0))
            
            
            
            navco %>% select(campaign,location,year,prim_method) %>% 
              mutate(violent = as.numeric(prim_method==0)) %>%
              group_by(campaign) 
            
            
            
            navco %>% mutate(violent = as.numeric(prim_method==0)) %>%
              group_by(campaign,location) %>% 
              summarize(total_years = n())
            
            
            
            navco %>% mutate(violent = as.numeric(prim_method==0)) %>%
              group_by(campaign,location) %>% 
              summarize(total_years = n(),
                        viol_years = sum(violent))
            
            
            
            navco %>% mutate(violent = as.numeric(prim_method==0)) %>%
              group_by(campaign,location) %>% 
              summarize(total_years = n(),
                        viol_years = sum(violent),
                        prop_viol = viol_years/total_years)
            
            
            
            navco %>% mutate(violent = as.numeric(prim_method==0)) %>%
              group_by(campaign,location) %>% 
              summarize(total_years = n(),
                        viol_years = sum(violent),
                        prop_viol = viol_years/total_years,
                        prop_viol = round(prop_viol,2))
            
            
            
            navco %>% mutate(violent = as.numeric(prim_method==0)) %>%
              group_by(campaign,location) %>% 
              summarize(total_years = n(),
                        viol_years = sum(violent),
                        prop_viol = viol_years/total_years,
                        prop_viol = round(prop_viol,2)) %>%
              arrange(desc(prop_viol)) 
            
            
            
            out <- navco %>% mutate(violent = as.numeric(prim_method==0)) %>%
              group_by(campaign,location) %>% 
              summarize(total_years = n(),
                        viol_years = sum(violent),
                        prop_viol = viol_years/total_years,
                        prop_viol = round(prop_viol,2)) %>%
              arrange(desc(prop_viol)) %>% ungroup() 
            
            
            View(out)
            
            # Here we've generated a nice summary of the data pertinent to our question.
            
            # We now know that it's rare for a movement to follow "mixed
            # methods" (nonviol & viol)
            
            table(out$prop_viol)
            
            
# Practice -----------------------------------------------------------------------
            
            # Using the NAVCO data... and using the dplyr approach to data manipulation
            
            # "cdivers_gender" is an indicator for gender diversity in a 
            # movement. Specifically,Whether the campaign embraces gender
            # diversity: 1 = diversity is present 0 = diversity is not present
            # -99=unknown. For each movment-year
            
            
            # (1) Of the 250 movements in the data, how many embrace gender
            # diversity for at least one year?
            
            
            
            
            
            
            
            
            
            # (2) "camp_goals" is an ordinal variable that states goals of the 
            # campaign. 
            
                    # 0=regime change 
                    # 1=significant institutional reform 
                    # 2=policy change 
                    # 3=territorial secession 
                    # 4=greater autonomy 
                    # 5=anti-occupation 
                    # -99=unknown
            
            # Given the following, which type of movement -- regime change or
            # secessionist -- tends to  embrace gender diversity more?
      
            

        
        
        

