###################################################
### An Introduction to Statistical Programming in R
### DAY 2 (April 4, 2016) 
### Eric Dunford (edunford@umd.edu)
###################################################
#########      DATA MANAGEMENT       ##############
###################################################
########### Operators and Variables ###############



# MATH OPERATORS ---------------------------------------------------------------

    # let's briefly review common operators by manipulating two objects: x and y
    
    x <- 3
    y <- 5
    
    # Mathematical Operators
    
          x + y  # addition
          x - y  # subtraction
          x * y  # multiplication
          x / y  # division
          x^y    # exponentiation
          x %*% y  # matrix multiplication
          
    # Mathematical Functions
          
          log(x) # Natural Log
          log(x,base = 10) # Log with another base
          exp(x) # exponential
          
          sum(1:100)
          mean(1:100)
          median(1:100)
          
          
          round(3.43455)
          round(3.43455,2)
          round(3.43455,3)
         
           
    # remember an object stores a specific piece of information, which we can 
    # manipulate down the line. Thus we can make piecewise changes and save each
    # step in a NEW OBJECT
          
          x <- 100
          x
          z <- x + 7
          z
          w <- z * 8
          w
          p <- w/1000
          p
          
    # Or overwrite each object
          
          x <- 100
          x
          x <- x + 7
          x
          x <- x * 8
          x
          x <- x/1000
          x
          
    # what's the dangers of overwriting when manipulating data?
          
          
          
# BOOLEAN OPERATORS ---------------------------------------------------------------   
            
    # Boolean ("logical") Operators
          
          x == y      # equals to
          x != y      # does not equal
          x >= y      # greater than or equal to
          x <= y      # less than or equal to
          x > y       # greater than
          x < y       # less than
          x==1 & y==5 # "and" conditional statements
          x==1 | y==5 # "or" conditional statements
          
    # Boolean ("logical") functions
          
          str <- "hello"
          num <- 1
          
        # for Class
          is.character(str)
          is.character(num)
          
          is.numeric(str)
          is.numeric(num)
          
        # for Data Type
          is.vector(str)
          is.vector(num) # vector of lenght 1
          
          is.matrix(str)
          is.data.frame(str)
          
        # For missing values
          is.na(NA)
          is.na(str)
    
    
   # Boolean statements can be used to SUBSET entire vectors and data structures
          
          vec <- c(1,5,0,9,10,100,.6,88,8.3,2.9,4)
          
          bool <- vec > 3
          
          # And we can use this statement to subset values within
          
          vec[bool]
          
          
          # Same for matrices and data frames
          
          mat <- matrix(1:25,ncol=5,nrow=5)
          
          bool2 <- mat > 10
          
          mat[bool2]
          
          
          # Interestingly we can use this property to quickly convert values
          
          mat[bool2] <- 1
          mat[!bool2] <- 0
          mat
          
          mat[bool2] <- "Yes"
          mat[!bool2] <- "No"
          mat
          
          
      # Checking if one list of values is located in another list of values
          
          values1 <- c("cat","dog","fish","cow")
          values2 <- c("zebra","panda","fish","moose","bee")
          
          values1 == values2 # didn't work!
          
          values1 %in% values2 # are any of values1 in the object values2?
          
          values1[values1 %in% values2]
          
          
          
# VARIABLES IN R ---------------------------------------------------------------   
          
          
          # Creating a data.frame from scratch
          
          # Let's assume we have three variables of equal length
          ID <- 1:6
          gender <- c("male","female","female","male","female","male")
          age <- c(23,31,46,19,24,35)
          voted <- c(NA,1,0,1,NA,1)
          
          ID
          gender
          age
          voted
          
          # We can combine these three data vectors together to create a data.frame
          
          df <- data.frame(ID,gender,age,voted)
          df
          
          
          dim(df) # dimensions
          nrow(df) # number of rows
          ncol(df) # number of columns
          
          colnames(df) # column names
          names(df)
          
          
          # Accessing the variables
          
              df[,1] # dimension
              
              df[,"gender"] # name
              
              df$gender # call
          
              
              
          # Generating a new dichotomous variable (i.e 1 or 0) if a respondent is male.
              
              male <- df$gender == "male"
          
              male
              
              as.numeric(male) # coerce the object to be numeric
              
              male_num <- as.numeric(male) 
          
              male_num
             
               
            # Naming the variable
              df$male  # Null because the variable hasn't been specified yet
              
              df$male <- 0  # let's fill "male" with a constant of 0
              df 
              
                    # Deleting that Variable
                    df$male <- NULL  
                    df
              
              
              df[,"male"] <- "m" # can specify the name within brackets
              df
              
                    # Deleting that Variable
                    ncol(df)
                    df <- df[,-5] # "minus this column"
                    df
              
                    
              df[,5] <- "Respondent is male" # can specify location (but it'll lack info re variable name)
              df
              
                    # Deleting that Variable
                    cnames <- colnames(df)
                    cnames
                    keep <- cnames != "V5"
                    keep
                    df <- df[,keep]
                    df
              
              
              male_num
              df$male <- male_num
              df
              
              
          # Categorical Variables
              
              class(df$gender)
              
              df$gender
              
              levels(df$gender)
              
              as.numeric(df$gender)
              
          # Subsetting Data Frames
              
              df$male == 1
              
              df[df$male == 1] #?
              
              df[ , df$male == 1]  # X
              
              df[df$male == 1, ] 
              
              df[df$male == 0, ] 
              
              df[df$age > 30, ] 
              
              df[df$age <= 25, ] 
              
              
              subset(df,age <= 25)
              subset(df,voted == 1)
              
              
          # Dropping Missing Data
              
              df$voted==NA # Why doesn't this work?
              
              is.na(df$voted) # missing
              !is.na(df$voted) # NOT missing
              
              
              subset(df,is.na(voted)) # is a missing value
              
              subset(df,!is.na(voted)) # is NOT a missing value
              
              
              df[is.na(df$voted),] # is a missing value
              
              df[!is.na(df$voted),] # is NOT a missing value
              
              
          # COMPLETE CASES
              
              # T/F for each row re: whether every value in that row is complete
              complete.cases(df) 
              
              df[complete.cases(df) , ]
              df[!complete.cases(df) , ]
              
              
          # REMEMBER: to save results we must store them in a new object
              
              df2 <- df[complete.cases(df) , ]
              
              df
              df2
              
              
# PRACTICE ----------------------------------------------------------
              
          
          # For the practice, let's load and use gss.Rdata which is data from the
          # 2006 General Social Survey (http://gss.norc.org/)
              
              setwd("") # Set your working directory to where your data is located
              
              load("gss.Rdata")
              
              
              
          # (1) create a dichotomous variable named "female" from the variable "sex"
              
              
          
              
              
              
          # (2) how many observations have no missing data?
              
             
              
          
              
              
          # (3) how many respondents did not answer if they voted in 2004?
              
              
              
              
              
          # (4) drop all respondents who did not vote in 2000?
              
              
              
          
          # (5) Create a variable called "satisfied" that is coded as 1 if the 
          # respondent answered "Very satisfied" or "Moderately satisfied", and 
          # as a 0 if he/she responded "A little dissatisfied" or "Very 
          # dissatisfied" and NA otherwise.
              
          